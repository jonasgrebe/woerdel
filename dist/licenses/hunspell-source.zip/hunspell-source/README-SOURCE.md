# Corresponding source for WORTWERK's Hunspell browser runtime

This archive supplies the Hunspell C++ source and the exact published build recipe identified by the vendored runtime's upstream package. The Hunspell C++ source is unmodified. WORTWERK uses its own small JavaScript adapter, and the generated runtime may be bundled/minified for delivery; the original generated file is included here for inspection and replacement.

## Verified provenance

1. The original generated browser runtime was extracted unchanged from `hunspell-asm@4.0.2`, path `dist/cjs/lib/browser/hunspell.js`.
2. That npm package's `package.json` identifies `config.hunspell-version` as `fc6a952-200131`.
3. Its upstream `bootstrap.ts` downloads the browser runtime from the identically named release of `kwonoj/docker-hunspell-wasm`.
4. The GitHub tag `fc6a952-200131` resolves to build-repository commit `fc6a952fd11ae95f4bce4118c1b41f5bee3d91d1`.
5. At that tag, `.circleci/config.yml` explicitly uses `BRANCH=v1.6.2` to build Hunspell. This is the actual Hunspell source version. The `fc6a952` prefix is a build-repository revision, not a Hunspell revision.
6. Hunspell tag `v1.6.2` resolves to commit `2730ad3d32d839f439ba7f286e3600cd9294a978`.

The captured GitHub tag responses and exact source trees are included. The npm package tarball SHA-256 is `92e28aae476e06962412d7e1b73571f10122539720b03e0f732428d389d2ca51`.

Original generated runtime SHA-512:

```
6fd6362ffaff2eed5bed2a437e106b5cac2a41a6b94ffe0b6757299a6569eeb2d9cdbf978f9e44e590a303838b6e51249d120aa8a8a376e366c7d486a158ff68
```

No independent bit-for-bit rebuild is claimed. Source correspondence is established by the exact npm package configuration and tagged upstream build recipe. The old release's separate `.sha512` asset was unavailable; this does not affect the supplied package file hash.

## Source locations

- Hunspell: https://github.com/hunspell/hunspell/tree/2730ad3d32d839f439ba7f286e3600cd9294a978
- Exact build recipe: https://github.com/kwonoj/docker-hunspell-wasm/tree/fc6a952fd11ae95f4bce4118c1b41f5bee3d91d1
- Package wrapper and provenance: https://github.com/kwonoj/hunspell-asm
- Package release: https://www.npmjs.com/package/hunspell-asm/v/4.0.2

## Build instructions

The original tagged `Dockerfile`, `build/build.sh`, `build/preprocessor.js`, and `.circleci/config.yml` are included in `docker-hunspell-wasm-fc6a952-200131/`. The Dockerfile identifies the historical compiler image `ojkwon/arch-emscripten:05fcce12-base`.

Original equivalent commands, executed inside that build-repository folder:

```sh
docker build -t wortwerk-hunspell-source --build-arg BRANCH=v1.6.2 --build-arg TARGET=wasm .
docker run --name wortwerk-hunspell-build wortwerk-hunspell-source /bin/bash -l -c './build.sh -o /out/hunspell_browser.js -s ENVIRONMENT=web,worker'
docker cp wortwerk-hunspell-build:/out/hunspell_browser.js ./hunspell_browser.js
```

The Docker build clones Hunspell and checks out v1.6.2. The supplied `hunspell-1.6.2/` tree is that same source, so a builder can use it locally instead of fetching it again. The script runs autotools/configure/make via Emscripten, then links `src/hunspell/.libs/libhunspell-1.6.a` into an embeddable single-file WebAssembly JavaScript module. The original flags, C exports and selective filesystem wrapper are preserved in the build source.

## Notices and source availability

Hunspell v1.6.2 is available under the MPL 1.1, GPL 2.0-or-later, or LGPL 2.1-or-later alternatives described by its original source notices. WORTWERK distributes the Hunspell component under the **MPL 1.1 alternative**, retaining the original alternative-license notices and providing this complete source archive. See `hunspell-1.6.2/COPYING.MPL`, `COPYING`, `COPYING.LESSER`, `license.hunspell`, and `license.myspell`. MySpell's BSD-style attribution and disclaimer are included separately in `THIRD-PARTY-NOTICES.txt`.

The npm wrapper package is MIT, copyright 2017 OJ Kwon; its original MIT license is included even though WORTWERK uses its own adapter instead of that wrapper. The generated runtime contains Emscripten support code. Emscripten's MIT/UIUC notices and bundled-library notices are included in `EMSCRIPTEN-LICENSE.txt` as license context (the exact compiler image is identified by the build Dockerfile; no unverified compiler version is claimed).

Keep this archive downloadable beside the distributed runtime. Preserve these license, author and source notices. The German dictionary is a separate GPL-2.0-or-GPL-3.0 data asset with its own source and notices.
